#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <errno.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <android/log.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>


#include "libxhook/xhook.h"
#include "net_rw.h"

static ssize_t (*orig_send)(int sockfd, const void *buf, size_t len, int flags) = NULL;

static char filename[1024] = {0};
static int file = -1;

static uint16_t packet_size;
static uint16_t packet_type;

ssize_t my_send(int sockfd, const void *buf, size_t len, int flags) {
	// both login credentials size same 582 bytes
	packet_size = read_u16(buf + 0);
	packet_type = read_u16(buf + 2);
		
	if (packet_size == 582 && packet_type == 0x0413) {
		// save login credentials 
		snprintf(filename, 1024, "/sdcard/lmlogin/MSG_NEWLOGIN_LOGINTOL.bin");
		file = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		write(file, buf, len);
		close(file);
	}
	
	if (packet_size == 582 && packet_type == 0x0414) {
		// save login credentials 
		snprintf(filename, 1024, "/sdcard/lmlogin/MSG_NEWLOGIN_LOGINTOP.bin");
		file = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		write(file, buf, len);
		close(file);
	}
	
    return orig_send(sockfd, buf, len, flags);
}


// Library constructor
__attribute__((constructor))
void on_load() {
	mkdir("/sdcard/lmlogin/", 0775);
	
	// Hook all loaded libraries
	xhook_register(".*\\.so$", "send", (void*)my_send, (void**)&orig_send);
	xhook_refresh(0);
}